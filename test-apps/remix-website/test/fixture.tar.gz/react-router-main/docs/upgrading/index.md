---
title: Upgrading to v6
order: 5
---
